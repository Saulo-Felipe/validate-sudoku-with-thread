OBSERVAÇÕES:

- Todo o código está na pasta "code";
- Para facilitar execução dos testes, disponibilizei os executaveis (win, mac, linux) na pasta "program";
    - Ao executa-lo, o programa ira considerar o arquivo "sudoku_matriz.json";
- Para os testes, vc pode alterar os valores do arquivo "sudoku_matriz.json";
